SILICLUSTER V3 - DIGITAL PROJECT SUBMISSION CANDIDATE
===================================================
Title: Digital EMG Activity Detector Using 64-Sample Mean Absolute Value (MAV64)
Type: Digital | Technology: SKY130 | Nominal supply: 1.8 V
Top module: silicluster_emg_top

DESCRIPTION
-----------
Digital 12-bit single-channel sample processor. It receives each ADC sample
in two 8-bit transfers, subtracts a configurable 12-bit offset, computes the
absolute magnitude, accumulates 64 samples, and outputs integer MAV (sum >> 6).
Configurable low/high thresholds implement hysteretic activity detection.
It does not incorporate an ADC or an analog front end.

PIN INTERFACE
-------------
Clock/reset (dedicated):
  clk           external rising-edge clock, design target <= 10 MHz
  rst           active-high synchronous reset
Digital inputs (14 total):
  data_in[7:0]  8-bit data/command bus                   (8)
  write_strobe  rising edge synchronized to clk        (1)
  command_mode  1=command, 0=payload byte             (1)
  view[1:0]    output-page selector                  (2)
  byte_select   0=low byte, 1=high byte               (1)
  enable        accepts writes when 1                (1)
Digital outputs (13 total):
  data_out[7:0] selected snapshot byte                (8)
  activity      hysteretic activity flag             (1)
  result_toggle toggles every complete 64 samples    (1)
  ack_toggle    toggles for each accepted write       (1)
  data_valid    at least one complete MAV result      (1)
  error_flag    bad command/payload/configuration     (1)

WRITE PROTOCOL
--------------
Toggle write_strobe from 0 to 1 while data_in and command_mode are stable;
inputs are sampled on the rising edge of clk. Return write_strobe to 0
before starting the next transfer.
Commands (command_mode=1):
  0  select sample write: expects low byte then upper nibble of sample
  1  select offset write: expects low byte then upper nibble of offset
  2  select low threshold: expects low byte then upper nibble
  3  select high threshold: expects low byte then upper nibble
  4  latch a snapshot for reading
  5  clear error flag
The next two transfers after commands 0..3 use command_mode=0:
  low 8 bits then upper 4 bits (bits [7:4] must be zero).
A complete 12-bit sample only enters the MAV accumulator after both bytes.
Commands 1..3 reset the partially accumulated window and activity state.
The low threshold must be below the high threshold.

OUTPUT READ
-----------
Issue command 4, then select view and byte_select:
  view=00  last centered signed value, sign-extended to 16 bits
  view=01  last magnitude (unsigned 12 bits)
  view=10  last MAV (unsigned 12 bits)
  view=11  snapshot status bits {error_flag,data_valid,activity}
read values using data_out byte_select=0 or 1. The snapshot persists until
command 4 is issued again.

RESET DEFAULTS
--------------
Offset=1995 ADC counts, low threshold=10, high threshold=16.
These defaults were selected for the bundled sample recordings, NOT for
universal EMG detection. Recalibrate to match sensor/user conditions.

VERIFICATION
------------
Files:
  silicluster_emg_top.v       top interface
  silicluster_emg_core.v      synthesizable Verilog RTL
  tb_silicluster.v           basic testbench
  tb_emg_real.v              real recordings + arithmetic reference
  test/reposo_ch0.hex        8000 12-bit samples
  test/cierre_ch0.hex        8000 12-bit samples

Test commands from the ZIP's root, with Icarus Verilog installed:
  iverilog -g2005 -s tb_silicluster -o basic.vvp silicluster_emg_core.v silicluster_emg_top.v tb_silicluster.v
  vvp -n basic.vvp
  iverilog -g2005 -s tb_emg_real -o emg.vvp silicluster_emg_core.v silicluster_emg_top.v tb_emg_real.v
  vvp -n emg.vvp

Previously observed in GitHub Actions on corresponding RTL/testbench:
  PASS: Silicluster wrapper + status smoke test
  REST: 125 windows, 0 active, last MAV=7
  CLOSE: 125 windows, 111 active, last MAV=52
  PASS: 16000 real EMG samples; 250 MAV64 windows matched golden reference
These are RTL simulations, not physical-chip measurements. The tests need to
be rerun for this standalone ZIP before it is submitted.

COMPATIBILITY NOTE
------------------
The synthesizable RTL uses ordinary Verilog. The testbench failure commands were converted from simulator-specific
constructs to Verilog-2005 $display and $stop/$finish. These modified
testbenches have NOT been rerun; validate on GitHub before sending.
Because a testbench's $finish can return success, the test runner MUST
check for the expected 'PASS:' messages, not only the process exit code.

The 180 x 115 um layout study was performed separately, but Silicluster's
published rules do not require a GDS for DIGITAL projects. Pin positioning,
top-level integration and final signoff remain subject to the organizers.
